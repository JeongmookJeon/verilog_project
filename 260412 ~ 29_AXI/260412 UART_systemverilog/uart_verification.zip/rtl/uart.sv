module uart #(
		parameter int BAUD_RATE = 9600
) (
	input			clk,
	input			rst,
	input	[7:0]	tx_data,
	input			tx_start,
	input			rx,
	output			tx,
	output			tx_busy,
	output	[7:0]	rx_data,
	output			rx_valid
);
	logic w_tick, rx_sync;

baud_rate_gen #(
	.BAUD_RATE(BAUD_RATE)
) U_BAUD_RATE_GEN
 (
		.clk(clk),
		.rst(rst),
		.tick(w_tick)
);

uart_tx U_UART_TX (
		.clk(clk),
		.rst(rst),
		.tick(w_tick),
		.tx_start(tx_start),
		.tx_data(tx_data),
		.tx(tx),
		.tx_busy(tx_busy)
);

sync_2ff U_SYNC_2FF (
		.clk(clk),
		.rst(rst),
		.async_in(rx),
		.sync_out(rx_sync)
);

uart_rx UART_RX (
		.clk(clk),
		.rst(rst),
		.tick(w_tick),
		.rx(rx_sync),
		.rx_data(rx_data),
		.rx_valid(rx_valid)	// rx_done
);

endmodule
