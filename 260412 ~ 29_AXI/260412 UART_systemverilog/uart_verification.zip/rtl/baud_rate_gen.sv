module baud_rate_gen #(
	parameter int BAUD_RATE = 9600
) (
		input			clk,
		input			rst,
		output logic	tick
);
localparam int CLK_DIV = 100_000_000 / (BAUD_RATE * 16) - 1;	// 16x oversampling

bit [$clog2(CLK_DIV)-1:0] cnt;

always_ff @(posedge clk, posedge rst) begin
	if (rst) begin
		tick <= 0;
		cnt <= 0;
	end
		if (cnt == CLK_DIV-1) begin
			cnt <= 0;
			tick <= 1'b1;
		end else begin
			cnt <= cnt + 1'b1;
			tick <= 1'b0;
		end
end

endmodule

