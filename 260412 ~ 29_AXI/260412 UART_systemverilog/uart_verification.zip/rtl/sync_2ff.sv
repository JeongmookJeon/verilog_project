module sync_2ff (
		input			clk,
		input			rst,
		input			async_in,
		output logic	sync_out
);

	logic ff1, ff2;
	assign sync_out = ff2;
	
	always_ff @(posedge clk, posedge rst) begin
		if (rst) begin
			ff1 <= 1'b1;	// rx high at first
			ff2 <= 1'b1;	// rx high at first
		end else begin
			ff1 <= async_in;
			ff2 <= ff1;
			//$monitor("[%0t] monitor in ff: ff1=%0d, ff2=%0d", $time, ff1, ff2);
		end
	end

endmodule
