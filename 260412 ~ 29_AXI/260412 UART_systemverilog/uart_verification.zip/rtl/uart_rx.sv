module uart_rx (
		input				clk,
		input				rst,
		input				tick,
		input				rx,
		output logic [7:0]	rx_data,
		output logic		rx_valid	// rx_done
);

	typedef enum bit [1:0] {
		IDLE,
		START,
		DATA,
		STOP
	} rx_state_e;

	rx_state_e state;

	bit [3:0] tick_cnt;
	bit [2:0] bit_cnt;
	logic [7:0] shift_reg;

	always_ff @(posedge clk, posedge rst) begin
		if (rst) begin
			state <= IDLE;
			tick_cnt <= 0;
			bit_cnt <= 0;
			shift_reg <= 0;
			rx_data <= 0;
			rx_valid <= 1'b0;
		end else begin
			case (state)
				IDLE: begin
					tick_cnt <= 0;
					bit_cnt <= 0;
					shift_reg <= 0;
					rx_data <= 0;
					rx_valid <= 0;
					if (rx == 1'b0) begin
						$display("[%0t] rx is going to START", $time);
						state <= START;
					end
				end
				START: begin
					if (tick) begin
						if (tick_cnt == 7) begin
							tick_cnt <= 0;
							$display("[%0t] rx is going to DATA", $time);
							state <= DATA;
						end else begin
							tick_cnt <= tick_cnt + 1'b1;
						end
					end
				end
				DATA: begin
					if (tick) begin
						if (tick_cnt == 15) begin
							tick_cnt <= 0;
							shift_reg <= {rx, shift_reg[7:1]};
							$display("[%0t|display] rx : bit_cnt=%0d, shift_reg=0x%0h", $time, bit_cnt, shift_reg);
							$monitor("[%0t|monitor] rx : bit_cnt=%0d, shift_reg=0x%0h", $time, bit_cnt, shift_reg);

							if (bit_cnt == 7) begin
								bit_cnt <= 0;
								state <= STOP;
								//rx_data <= shift_reg;
								//rx_valid <= 1'b1;
								$display("[%0t] rx is going to STOP", $time);
							end else begin
								bit_cnt <= bit_cnt + 1'b1;
							end
						end else begin
							tick_cnt <= tick_cnt + 1'b1;
						end
					end
				end
				STOP: begin
					rx_data <= shift_reg;
					rx_valid <= 1'b1;
					if (tick) begin
						if (tick_cnt == 15) begin
							tick_cnt <= 0;
								$display("[%0t] rx is going to IDLE", $time);
							state <= IDLE;
						end else begin
							tick_cnt <= tick_cnt + 1'b1;
						end
					end
				end
				default: begin
					state <= IDLE;
					// rx_data <= 0;
					// rx_vaild <= 1'b0;
				end
			endcase
		end
	end

endmodule
