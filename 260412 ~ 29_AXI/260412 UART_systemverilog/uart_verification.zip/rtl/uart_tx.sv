module uart_tx (
		input					clk,
		input					rst,
		input					tick,
		input					tx_start,
		input			[7:0]	tx_data,
		output logic			tx,
		output logic			tx_busy
);
	typedef enum bit [1:0] {
		IDLE,
		START,
		DATA,
		STOP
	} tx_state_e;

	tx_state_e state;

	logic [3:0] tick_cnt;
	logic [2:0] bit_cnt;
	logic [7:0] shift_reg;

	always_ff @(posedge clk, posedge rst) begin
		if (rst) begin
			state		<= IDLE;
			tick_cnt	<= 0;
			bit_cnt		<= 0;
			shift_reg	<= 0;
			tx			<= 1'b1;	// HIGH at IDLE
			tx_busy		<= 1'b0;
		end else begin
			case (state)
				IDLE: begin
					tx		<= 1'b1;	// HIGH at IDLE
					tx_busy <= 1'b0;
					
					if (tx_start) begin
						shift_reg	<= tx_data;
						tick_cnt	<= 0;
						bit_cnt		<= 0;
						tx_busy		<= 1'b1;
						state		<= START;
								$display("[%0t] tx is going to START", $time);
					end
				end
				START: begin
					tx		<= 1'b0;	// START bit
					tx_busy <= 1'b1;
					if (tick) begin
						if (tick_cnt == 15) begin
							tick_cnt	<= 0;
							state		<= DATA;
								$display("[%0t] tx is going to DATA", $time);
						end else begin
							// state <= START;
							tick_cnt	<= tick_cnt + 1'b1;
						end
					end
				end
				DATA: begin
					tx <= shift_reg[0];	// send from lsb to msb
					if (tick) begin
						if (tick_cnt == 15) begin
							tick_cnt	<= 0;
							shift_reg	<= {1'b0, shift_reg[7:1]};

							if (bit_cnt == 7) begin
								bit_cnt <= 0;
								state	<= STOP;
								$display("[%0t] tx is going to STOP", $time);
							end else begin
								bit_cnt <= bit_cnt + 1'b1;
							end
						end else begin
							tick_cnt	<= tick_cnt + 1'b1;
						end
					end
				end
				STOP: begin
					tx <= 1'b1;	// STOP bit
					if (tick) begin
						if (tick_cnt == 15) begin
							tick_cnt	<= 0;
							tx_busy		<= 1'b0;
							state		<= IDLE;
								$display("[%0t] tx is going to IDLE", $time);
						end else begin
							tick_cnt	<= tick_cnt + 1'b1;
						end
					end
				end
				default: begin
					state <= IDLE;
					tx <= 1'b1;
				end
			endcase
		end
	end
endmodule
