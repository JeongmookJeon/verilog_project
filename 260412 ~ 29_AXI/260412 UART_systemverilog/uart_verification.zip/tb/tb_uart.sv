module tb_uart();

	bit				clk;
	bit				rst;
	bit		[7:0]	tx_data;
	bit				tx_start;
	//logic			tx;
	logic			tx_busy;
	//logic			rx;
	logic	[7:0]	rx_data;
	logic			rx_valid;
	
	logic tx_rx;
	logic [7:0] tx_data_temp, rx_data_temp;

uart #(
		.BAUD_RATE(9600)
) (
	.clk(clk),
	.rst(rst),
	.tx_data(tx_data),
	.tx_start(tx_start),
	.tx(tx_rx),
	.tx_busy(tx_busy),
	.rx(tx_rx),
	.rx_data(rx_data),
	.rx_valid(rx_valid)
);

		int loop = 10;
		int pass=0;
		int fail=0;
		//event next_ev;

	task send_data(int loop);
		repeat(loop) begin
//			tx_data = data;
			tx_data = $urandom();
			tx_data_temp = tx_data;
			$display("[%0t] generated tx_data=0x%0h", $time, tx_data_temp);
			tx_start = 1'b1;
			@(posedge clk);
			@(posedge clk);
			

			tx_start = 1'b0;
			// @(posedge clk);
			#105000;	// #104_166;

			wait (tx_busy==1'b0);
			@(posedge clk);

			$display("[%0t] SEND : waiting for event...", $time);
			//@(next_ev);
		end
	endtask

	task receive_data(int loop);
		forever begin
			@(posedge rx_valid);
			@(posedge clk);
			//@(posedge clk);
			rx_data_temp = rx_data;
			if (rx_data_temp == tx_data_temp) begin
				$display($sformatf("[%0t] PASS! data: 0x%0h", $time, rx_data_temp));
				pass++;
			end else begin
				$display($sformatf("[%0t] FAIL! tx_data: 0x%0h, rx_data: 0x%0h", $time, tx_data_temp, rx_data_temp));
				fail++;
			end
			//->next_ev;
		end
	endtask


	always #5 clk =~clk;

	initial begin
		clk = 0;
		rst = 1;
		repeat(3) @(posedge clk);
		rst = 0;
		repeat(3) @(posedge clk);

		
		fork

		send_data(loop);
		receive_data(loop);

		join_any


		//send_data(8'h55);
		//send_data(8'h11);
		//send_data(8'hff);

		#200;
		$display("[%0t] pass=%0d, fail=%0d", $time, pass, fail);
		$stop;
		// $finish;
	end

	initial begin
		$fsdbDumpfile("novas.fsdb");
		$fsdbDumpvars(0, tb_uart, "+all");
	end

endmodule
