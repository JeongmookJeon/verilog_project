`include "uvm_macros.svh"
import uvm_pkg::*;


interface uart_if(
		input clk,
		input rst
);
	bit [7:0]	tx_data;
	bit		tx_start;
	logic			tx;
	logic			tx_busy;
	logic			rx;
	logic	 [7:0]	rx_data;
	logic			rx_valid;

	clocking drv_cb @(posedge clk);
		default input #1step output #0;
		
		output tx_data;
		output tx_start;
		input tx;
		input tx_busy;
		input rx;
		input rx_data;
		input rx_valid;
	endclocking

	clocking mon_cb @(posedge clk);
		default input #1step;

		input tx_data;
		input tx_start;
		input tx;
		input tx_busy;
		input rx;
		input rx_data;
		input rx_valid;
	endclocking

endinterface

class uart_seq_item extends uvm_sequence_item;
	rand logic [7:0] tx_data;
	logic [7:0] rx_data;

	`uvm_object_utils_begin(uart_seq_item)
		`uvm_field_int(tx_data, UVM_ALL_ON)		// register to factory to use UVM functions : e.g., compare...
		`uvm_field_int(rx_data, UVM_ALL_ON)		
	`uvm_object_utils_end


	constraint c_tx_data {
		tx_data inside {[8'h00:8'hff]};		// to deal with corner case ??
	}

	function new(string name = "uart_seq_item");
		super.new(name);
	endfunction

	function string convert2string();
		return $sformatf("tx_data=0x%02h, rx_data=0x%02h", tx_data, rx_data);
	endfunction


endclass

/*
class uart_base_sequence extends uvm_sequence;
	`uvm_object_utils(uart_base_sequence)

	uart_env env;

	function new(string name = "uart_sequence");
		super.new(name);
	endfunction
endclass
*/

class uart_rand_seq extends uvm_sequence #(uart_seq_item);
	`uvm_object_utils(uart_rand_seq)
	int num_trans = 10;

	function new(string name = "uart_rand_seq");
		super.new(name);
	endfunction

	task body();
		uart_seq_item item;
		repeat(num_trans) begin
			item = uart_seq_item::type_id::create("item");
			start_item(item);
			if (!item.randomize()) begin
				`uvm_fatal(get_type_name(), "randomization failed")
			end
			`uvm_info(get_type_name(), $sformatf("seq sent: %s", item.convert2string()), UVM_MEDIUM)
			finish_item(item);
		end
	endtask

endclass



class uart_driver extends uvm_driver #(uart_seq_item);
	`uvm_component_utils(uart_driver)
	virtual uart_if u_if;

	function new(string name = "uart_driver", uvm_component parent);
		super.new(name, parent);
	endfunction

	virtual function void build_phase(uvm_phase phase);
		super.build_phase(phase);
		if (!uvm_config_db#(virtual uart_if)::get(this, "", "u_if", u_if)) begin
			`uvm_fatal(get_type_name(), "cannot access to interface")
		end
	endfunction

	virtual task run_phase(uvm_phase phase);
		uart_seq_item item;

		// initialization
		u_if.tx_data <= 8'h00;
		u_if.tx_start <= 1'b0;

		wait(u_if.rst==0);			// option 1
		//@(negedge u_if.drv_cb.rst);		// option 2
		//wait(u_if.drv_cb.rst==0);
		repeat (3) @(u_if.drv_cb);

		forever begin
			seq_item_port.get_next_item(item);
			
			// wait while tx_busy is HIGH
			while(u_if.drv_cb.tx_busy) @(u_if.drv_cb);
			@(u_if.drv_cb);

			u_if.drv_cb.tx_data <= item.tx_data;
			u_if.drv_cb.tx_start <= 1'b1;	// item.tx_start;
			@(u_if.drv_cb);
			u_if.drv_cb.tx_start <= 1'b0;
			`uvm_info(get_type_name(), $sformatf("tx start: tx_data = 0x%02h", item.tx_data), UVM_HIGH)
			@(u_if.drv_cb);
			
			while(!u_if.drv_cb.tx_busy) @(u_if.drv_cb);	// wait until busy is HIGH	(tx started)
			while(u_if.drv_cb.tx_busy)	@(u_if.drv_cb);	// wait until busy is LOW	(tx finished)
			`uvm_info(get_type_name(), $sformatf("tx finished: tx_data = 0x%02h", item.tx_data), UVM_HIGH)
			
			while(u_if.drv_cb.rx_valid) @(u_if.drv_cb);	// wait until rx_valid (rx_done?)
			item.rx_data = u_if.drv_cb.rx_data;
			`uvm_info(get_type_name(), $sformatf("rx finished: rx_data = 0x%02h", item.rx_data), UVM_HIGH)
			@(u_if.drv_cb);

			seq_item_port.item_done();//item);
		end
	endtask

endclass
class uart_monitor extends uvm_monitor;
	`uvm_component_utils(uart_monitor)
	virtual uart_if u_if;
	uvm_analysis_port #(uart_seq_item) ap;

	function new(string name = "uart_monitor", uvm_component parent);
		super.new(name, parent);
	endfunction

	virtual function void build_phase(uvm_phase phase);
		super.build_phase(phase);
		if (!uvm_config_db#(virtual uart_if)::get(this, "", "u_if", u_if)) begin
			`uvm_fatal(get_type_name(), "cannot access to interface")
		end
		ap = new("ap", this);
	endfunction


	virtual task run_phase(uvm_phase phase);
		forever begin
			uart_seq_item item = uart_seq_item::type_id::create("item", this);
			@(u_if.mon_cb.tx_start);
			if (u_if.mon_cb.tx_start) begin
				item.tx_data = u_if.mon_cb.tx_data;
				`uvm_info(get_type_name(), $sformatf("[TX] tx_data = 0x%02h", item.tx_data), UVM_HIGH)
			wait(u_if.mon_cb.rx_valid);
				item.rx_data = u_if.mon_cb.rx_data;
				`uvm_info(get_type_name(), $sformatf("[RX] rx_data = 0x%02h", item.rx_data), UVM_HIGH)
				ap.write(item);
			end
			
		end
	endtask

endclass
class uart_agent extends uvm_agent;
	`uvm_component_utils(uart_agent)

	uart_driver drv;
	uart_monitor mon;
	uvm_sequencer #(uart_seq_item) sqr;

	function new(string name = "uart_agent", uvm_component parent);
		super.new(name, parent);
	endfunction

	virtual function void build_phase(uvm_phase phase);
		super.build_phase(phase);
		drv = uart_driver::type_id::create("drv", this);
		mon = uart_monitor::type_id::create("mon", this);
		sqr = uvm_sequencer#(uart_seq_item)::type_id::create("sqr", this);
	endfunction

	virtual function void connect_phase(uvm_phase phase);
		super.connect_phase(phase);
		drv.seq_item_port.connect(sqr.seq_item_export);
	endfunction

endclass

class uart_scoreboard extends uvm_scoreboard;
	`uvm_component_utils(uart_scoreboard)
	uvm_analysis_imp #(uart_seq_item, uart_scoreboard) ap_imp;
	int pass_cnt = 0;
	int fail_cnt = 0;

	function new(string name = "uart_scoreboard", uvm_component parent);
		super.new(name, parent);
	endfunction

	virtual function void build_phase(uvm_phase phase);
		super.build_phase(phase);
		ap_imp = new("ap_imp", this);
	endfunction

	function void write(uart_seq_item item);
		if (item.tx_data != item.rx_data) begin
			`uvm_error(get_type_name(), $sformatf("[FAIL] tx_data=0x%0h, rx_data=0x%0h", item.tx_data, item.rx_data))
			fail_cnt++;
		end else begin
			`uvm_info(get_type_name(), $sformatf("[PASS] data=0x%0h", item.rx_data), UVM_LOW)
			pass_cnt++;
		end
	endfunction

	virtual function void report_phase(uvm_phase phase);
		super.report_phase(phase);
		`uvm_info(get_type_name(), $sformatf("\n\n===== Scoreboard Summary ====="), UVM_LOW)
		`uvm_info(get_type_name(), $sformatf("pass=%0d/%0d", pass_cnt, pass_cnt+fail_cnt), UVM_LOW)
		`uvm_info(get_type_name(), $sformatf("fail=%0d/%0d", fail_cnt, pass_cnt+fail_cnt), UVM_LOW)
		if (fail_cnt) begin
			`uvm_error(get_type_name(), $sformatf("TEST Failed: %d mismatches", fail_cnt))
		end else begin
			`uvm_info(get_type_name(), $sformatf("TEST Passed: %d matches", pass_cnt), UVM_LOW)
		end
		`uvm_info(get_type_name(), $sformatf("===== Scoreboard Summary =====\n\n"), UVM_LOW)
	endfunction
endclass

class uart_coverage extends uvm_subscriber #(uart_seq_item);
	`uvm_component_utils(uart_coverage)

	logic [7:0] cov_tx_data;

	covergroup cg_data;
		cp_tx_data: coverpoint cov_tx_data {
			bins zero = {8'h00};
			bins alt_01 = {8'h55};
			bins alt_10 = {8'haa};
			bins lsb_only = {8'h01};
			bins msb_only = {8'h80};
			bins low = {[8'h00:8'h3f]};
			bins mid = {[8'h40:8'hbf]};
			bins high = {[8'hc0:8'hff]};
		}
	endgroup

		function new(string name = "uart_coverage", uvm_component parent);
			super.new(name, parent);
			cg_data = new();
		endfunction

		function void write(uart_seq_item item);
			cov_tx_data = item.tx_data;
			cg_data.sample();
		endfunction

		function void report_phase(uvm_phase phase);
			`uvm_info(get_type_name(), $sformatf("coverage: cg_data=%.1f%%", cg_data.get_coverage()), UVM_LOW)
		endfunction

endclass

class uart_env extends uvm_env;
	`uvm_component_utils(uart_env)

	uart_agent agt;
	uart_scoreboard scb;
	uart_coverage cov;

	function new(string name = "uart_env", uvm_component parent);
		super.new(name, parent);
	endfunction

	virtual function void build_phase(uvm_phase phase);
		super.build_phase(phase);
		agt = uart_agent::type_id::create("agt", this);		
		scb = uart_scoreboard::type_id::create("scb", this);
		cov = uart_coverage::type_id::create("cov", this);
	endfunction

	virtual function void connect_phase(uvm_phase phase);
		super.connect_phase(phase);
		agt.mon.ap.connect(scb.ap_imp);
		agt.mon.ap.connect(cov.analysis_export);
	endfunction

endclass

class uart_rand_test extends uvm_test;
	`uvm_component_utils(uart_rand_test)

	uart_env env;

	function new(string name = "uart_base_test", uvm_component parent);
		super.new(name, parent);
	endfunction

	virtual function void build_phase(uvm_phase phase);
		super.build_phase(phase);
		env = uart_env::type_id::create("env", this);		
	endfunction

	virtual function void connect_phase(uvm_phase phase);
		super.connect_phase(phase);
	endfunction

	virtual task run_phase(uvm_phase phase);
		uart_rand_seq seq;
		phase.raise_objection(this);
		seq = uart_rand_seq::type_id::create("seq");//, this);
		seq.start(env.agt.sqr);
		phase.drop_objection(this);
	endtask

endclass

module tb_uart_uvm();

	bit clk;
	bit rst;

	uart_if u_if(clk, rst);

	uart #(
			.BAUD_RATE(9600)
	) dut (
		.clk(clk),
		.rst(rst),
		.tx_data(u_if.tx_data),
		.tx_start(u_if.tx_start),
		.tx(u_if.tx),
		.tx_busy(u_if.tx_busy),
		.rx(u_if.rx),
		.rx_data(u_if.rx_data),
		.rx_valid(u_if.rx_valid)
	);

	// loopback
	assign u_if.rx = u_if.tx;

	always #5 clk = ~clk;

	initial begin
		clk = 0;
		rst = 1;
		repeat(3) @(posedge clk);
		rst = 0;
		@(posedge clk);
	end

	initial begin
		uvm_config_db #(virtual uart_if)::set(null, "*", "u_if", u_if);
		run_test("uart_rand_test");

		#100;
		$finish;
	end

	initial begin
		$fsdbDumpfile("novas.fsdb");
		$fsdbDumpvars(0, tb_uart_uvm, "+all");
	end

endmodule
