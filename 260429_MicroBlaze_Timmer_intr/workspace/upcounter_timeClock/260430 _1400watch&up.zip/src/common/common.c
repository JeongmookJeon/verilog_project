/*
 * common.c
 *
 *  Created on: 2026. 4. 28.
 *      Author: kccistc
 */
#include "common.h"

uint32_t millis_tick = 0;

uint32_t millis() {
	return millis_tick;
}

//1ms ���ݸ��� 1�� ����
void millis_inc() {
	millis_tick++;
}

void delay_ms(uint32_t msec)
{
	//usleep(msec*1000);
	delay_us(msec*1000);
}

//�����̴� ī���� �̿�
void delay_us(uint32_t usec)
{
	uint32_t prevtimer = TMR_GetCNT(TMR0);

	while (TMR_GetCNT(TMR0) - prevtimer < usec);

	//usleep(usec);
}


