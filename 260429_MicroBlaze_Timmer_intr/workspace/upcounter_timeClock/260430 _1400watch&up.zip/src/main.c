#include "ap/ap_main.h"
#include "xparameters.h"

int main()
{
	//ap �ʱ�ȭ
	ap_init();

	while(1)
	{
		//ap ����
		ap_excute();
	}

	return 0;
}
